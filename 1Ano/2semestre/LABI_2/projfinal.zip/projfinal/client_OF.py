import socket
import random
import json
import hashlib
from Crypto.Cipher import AES
import base64

def connect_tcp():
	tcp_s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	tcp_s.bind( ("0.0.0.0", 0))	
	# Ligar ao servidor
	tcp_s.connect( ("xcoa.av.it.pt", 8080) )
	return tcp_s
    
def get_key(server):
	#valores iniciais
	p = 1343270965545476954223465975446
	g = 46756894379
	a = (int)(random.random()*10)
    
	#instrução de ligação para o servidor
	server.send(("CONNECT " + str(pow(g,a,p)) + "," +str(p) + "," + str(g) +"\n").encode("utf-8"))
	
	#retirar o TOKEN dos dados recebidos
	data = server.recv(4098)
	data = data.decode("utf-8")
	data = json.loads(data)
	token = data["TOKEN"]
	
	#calculo da chave: X
	b = data["B"]
	X = pow(b,a,p)
	X = str(X).encode("utf-8")
	MD5 = hashlib.md5()
	MD5.update(X)
	X = MD5.hexdigest()
	X = X[0:16]
	return X, token

def encode_data(data, key):
	cipher = AES.new(key)
	
	#acertar o tamanho do ultimo bloco
	lastBlockLen = len(data) % cipher.block_size
	if (lastBlockLen != cipher.block_size):
		p = cipher.block_size - len(data)
		data = data + chr(p)*p
	#encriptar os dados e codificar em base 64
	data = cipher.encrypt(data)
	data = base64.b64encode(data)+"\n".encode("utf-8")
	return data

def get_data(server, key):
	cipher = AES.new(key)
	
	data = server.recv(4096)
	data = base64.b64decode(data)
	data = cipher.decrypt(data)
	p = data[len(data)-1]
	data = data[0:len(data)-p]
	return data

def main():


	server = connect_tcp()
	print("CONECTED")

	X, token = get_key(server)


	
	data = ("READ " + str(token))

	data = encode_data(data, X)

	server.send(data)

	print("data sended")

	while 1:
		print(get_data(server, X).decode("utf-8"))
    
main()
