import socket 
import csv
import sys
import json

def connect():
    server_adress = ('xcoa.av.it.pt', 8080)
    s.connect(server_adress)

def get_token():
    message_connect = "CONNECT\n"
    s.send(message_connect.encode("utf-8"))
 
def read(TOKEN):  
    try:  
        token = json.loads(TOKEN)
    except:
        return False
    string_token = str(token["TOKEN"])
    message_read = ("READ " + string_token + "\n")
    s.send(message_read.encode("utf-8"))
    OK = s.recv(1024).decode("utf-8")
    print(OK)
    return True

def values(writer, csvfile):
    i = 0
    while i < 5: 
        if True:
            values = json.loads(s.recv(1024).decode("utf-8"))
            string_wind = str(values["WIND"])
            string_humidity = str(values["HUMIDITY"])
            string_temperature = str(values["TEMPERATURE"])
            writer.writerow({"WIND":string_wind, "HUMIDITY":string_humidity, "TEMPERATURE":string_temperature})
            csvfile.flush()
            i = i + 1
        print(values)
        
        if(float(string_humidity) > 80 and float(string_temperature) > 27):
            print("Hidrate-se bastante! É recomendado o uso de roupas frescas e boné.")
        elif((55 < float(string_humidity) < 80) and (10 < float(string_temperature) < 20)):
            print("Há forte probabilidade de precipitação: previna-se e leve o guarda-chuva consigo.")
            if(float(string_wind) > 15):
                print("Vento forte, use um cachecol para se prevenir.")
        elif(float(string_humidity) < 20 and float(string_temperature) < 10):
            print("Muito frio. O uso de casaco e gorro é recomendado.")
            if(float(string_wind) > 10):
                print("Leve também um cachecol! O vento está forte.")
        elif(40 < float(string_humidity) < 70 and 16 < float(string_temperature) < 25):
            print("O tempo está agradável, vista roupa fresca acompanhada de um casaco fino.")
        elif(float(string_temperature) < 5):
            print("Faz imenso frio, além de roupa quente e um bom casaco, faça-se acompanhar de luvas e gorro!")
        elif(float(string_temperature) > 28 and float(string_wind) < 5):
            print("Está um dia caloroso! Vista um biquíni e aproveita a praia.")
        elif(float(string_humidity) > 60 and float(string_temperature) > 12):
            print("O frio não passa despercebido: agasalhe-se e não dispense um bom casaco.") 
        
    s.close()
    csvfile.close()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect()
get_token()
TOKEN = s.recv(1024).decode("utf-8")   
print (TOKEN)

while not read(TOKEN):
    pass
csvfile = open("values.csv", "w", newline="")
writer = csv.DictWriter(csvfile, fieldnames=['WIND', 'HUMIDITY', 'TEMPERATURE'])
writer.writeheader()
values(writer, csvfile)

 
