Projeto LABI
