import socket 
 
import csv
 
import sys
 
import json

def client():
 
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 
    server_adress = ('xcoa.av.it.pt', 8080)

    s.connect(server_adress)

    message1 = "CONNECT\n"
 
    s.send(message1.encode("utf-8"))
 
    connect = s.recv(1024).decode("utf-8")
 
    print (connect)

    token = json.loads(connect)
 
    print(token)
 
    for i in token : 
 
        token = str(token[i])
 
    message2 = ("READ " + token + "\n")  
 
    s.send(message2.encode("utf-8"))
 
    while 1:
       read = s.recv(1024).decode("utf-8") 

       print (read)
       
client()
 