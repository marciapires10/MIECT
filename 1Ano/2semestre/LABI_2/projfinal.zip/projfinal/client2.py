import socket 
 
import csv
 
import sys
 
import json

def out_file():
	
	fout = open('values1.csv', 'w')
	writer = csv.DictWriter(fout, fieldnames=['WIND', 'HUMIDITY', 'TEMPERATURE'])
	
	writer.writeheader()
	
	return writer


def client():
 
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
 
    server_adress = ('xcoa.av.it.pt', 8080)

    s.connect(server_adress)

    message1 = "CONNECT\n"
 
    s.send(message1.encode("utf-8"))
 
    connect = s.recv(1024).decode("utf-8")
 
    print (connect)

    token = json.loads(connect)
 
    print(token)
 
    for i in token : 
 
        id = str(token[i])
 
    message2 = ("READ " + id + "\n")  
 
    s.send(message2.encode("utf-8"))
    resposta = s.recv(1024).decode("utf-8")
    print ('ok', resposta)
	
    writer = out_file()
	
    while 1:
       try:
         read = s.recv(1024).decode("utf-8") 
       except:
         continue

       
       print ('while', read)
       
       d = json.loads(read)
       
       cont = False
       for k in d:
           if k not in ['WIND', 'HUMIDITY', 'TEMPERATURE']:
               cont = True
			   
       if cont:
          continue
		   	   
       print(d)
       
       writer.writerow(d)
		 
		 
client()

 
