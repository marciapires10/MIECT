import socket 
import csv
import sys
import json

def connect():
    server_adress = ('xcoa.av.it.pt', 8080)
    s.connect(server_adress)

def get_token():
    message_connect = "CONNECT\n"
    s.send(message_connect.encode("utf-8"))
 
def read(TOKEN):  
    try:  
        token = json.loads(TOKEN)
    except:
        return False
    string_token = str(token["TOKEN"])
    message_read = ("READ " + string_token + "\n")
    s.send(message_read.encode("utf-8"))
    OK = s.recv(1024).decode("utf-8")
    print(OK)
    return True

def values(writer, csvfile):
    i = 0
    while i < 5: 
        if True:
            values = json.loads(s.recv(1024).decode("utf-8"))
            string_wind = str(values["WIND"])
            string_humidity = str(values["HUMIDITY"])
            string_temperature = str(values["TEMPERATURE"])
            writer.writerow({"WIND":string_wind, "HUMIDITY":string_humidity, "TEMPERATURE":string_temperature})
            csvfile.flush()
            i = i + 1
        print(values)
    s.close()
    csvfile.close()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connect()
get_token()
TOKEN = s.recv(1024).decode("utf-8")   
print (TOKEN)
while not read(TOKEN):
    pass
csvfile = open("values.csv", "w", newline="")
writer = csv.DictWriter(csvfile, fieldnames=['WIND', 'HUMIDITY', 'TEMPERATURE'])
writer.writeheader()
values(writer, csvfile)

 
