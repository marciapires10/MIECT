print('ola')
print(1)
print(5.5)
print(True)

a = 10
print('int', a)
a = 5.5
print('double', a)

b = 'a' + str(a)
print(b)

c = int(input('valor?'))
print('c = ', c)