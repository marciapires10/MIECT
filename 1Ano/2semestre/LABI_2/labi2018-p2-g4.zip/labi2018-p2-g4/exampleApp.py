#!python
# Example of a cherrypy application that serves static content,
# as well as dynamic content.
#
# JMR@ua.pt 2016
#
# To run:
#	python exampleApp.py

import os.path
import cherrypy
import samples
import songs

# The absolute path to this file's base directory:
baseDir = os.path.dirname(os.path.abspath(__file__))

# Dict with the this app's configuration:
config = {
  "/":     { "tools.staticdir.root": baseDir },
  "/js":   { "tools.staticdir.on": True,
             "tools.staticdir.dir": "js" },
  "/css":  { "tools.staticdir.on": True,
             "tools.staticdir.dir": "css" },
  "/html": { "tools.staticdir.on": True,
             "tools.staticdir.dir": "html" },
  "/imagens":{"tools.staticdir.on": True,
             "tools.staticdir.dir": "imagens"},
  "/fonts":{"tools.staticdir.on": True,
             "tools.staticdir.dir": "fonts"},
}

class Root:
    # This class atribute contains the HTML text of the main page:
    indexHTML = """<html>
       <head>
       <title>CherryPy static example</title>
       <link href="../css/style.css" rel = "stylesheet" type="text/css">
       <script
       type="application/javascript"
       src="js/JS.js"></script>

       </head>
       <body>
       <h1>This is the main (index) page, served dynamically.</h1>
       You should have seen an Alert before this page.
       <p>This is a paragraph, that should be green.</p>
       This is a <a href="html/Proj2LABI.html">link to a static page</a>
       </body>
       </html>
       """

    @cherrypy.expose
    def index(self):
       return Root.indexHTML

    @cherrypy.expose
    def dynamic2(self):
       return "This is dynamic2"
       
    @cherrypy.expose
    def list(self,type):
        if (type=="songs"):
          return songs.convert_songs();
        elif(type=="samples"):
          return samples.convert_samples();

cherrypy.quickstart(Root(), "/", config)

