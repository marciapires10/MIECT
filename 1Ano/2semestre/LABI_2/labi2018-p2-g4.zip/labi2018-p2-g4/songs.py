import sqlite3
import json

def convert_songs():
    connection = sqlite3.connect('nossa database das musicas.db')
    cursor = connection.cursor()
    query = "SELECT * FROM items"
    result = cursor.execute(query)

    items = []

    for row in result:
        for key in cursor.description:
            items.append({key[0]: value for value in row})
    json.dumps({'items': items})