% Ex1, fun��o para inserir um elemento (ou elementos)

function func_ins = insert(array, nHashes, obj)
  
  for i=1:length(nHashes)
    
    hashValue = hash(obj, length(array), nHashes(i));
    func_ins(hashValue) = 1;
    
  endfor
endfunction
