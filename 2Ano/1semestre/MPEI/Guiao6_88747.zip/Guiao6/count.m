function func_count = count(array, k, word)
  sizeArray = length(array);
  
  val = zeros(1, k);
  
  for i=1:k
    
    word = [word num2str(i)];
    x = rem(string2hash(word), sizeArray) +1;
    val(i) = array(x);
    
  endfor
  
  val = min(val);
  
endfunction
