%% Ex1 e 2

listaP = {'Egito', 'Colombia', 'Jordania', 'Myanmar', 'Peru'};
teste = {'Turquia', 'Finlandia', 'Peru', 'Hungria'};

m = 100;
k = 3;

ini_bf = inicialize(m);

for i=1:length(listaP)
  
  ini_bf = insert(ini_bf, k, listaP{i}); 
  
endfor

for i=1:length(teste)
  
  if verify(ini_bf, k, teste{i})
    fprintf("%s Pertence \n", teste{i});
    
  else
    fprintf("%s N�o pertence \n", teste{i});
    
  end
  
endfor
