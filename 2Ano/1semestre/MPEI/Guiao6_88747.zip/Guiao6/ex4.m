%% Ex4

alfa_PT = ['a':'z', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', ...
    '�', '�', 'A':'Z', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', ...
    '�', '�', '0':'9']; 

files = {'pg21209.txt','pg26017.txt'};
pmf_PT = pmfLetrasPT(files, alfa_PT);
distLettersPT = cumsum(pmf_PT);
    

nStr = 1000;
sizeStr = 40;

nTest = 10000;
false_positives = zeros(15,1);
false_positivesT = zeros(15,1); % te�rico

for nHashes = 1:15
  
  bar = waitbar(0, sprintf('Gerando o bloom filter para k=%d', nHashes));
  
  nBloom = inicialize(8000);
  hashes = inicialize(nHashes);
  
  for i=1:nHashes
  
  hashes(i) = ceil(rand()*1000);
  
  endfor

  for i=1:nStr
    
    randStr = geraStrPT(sizeStr, alfa_PT, distLettersPT);
    nBloom = insert(nBloom, nHashes, randStr);
  end
  
  false_positivesT(nHashes, :) = (1 - exp(-nHashes*nStr/nTest))^nHashes;
  
  for i=1:nTest
    
    waitbar(i/nTest, bar);
    
    testStr = geraStrPT(sizeStr, alfa_PT, distLettersPT);
    
    if(verify(nBloom, nHashes, testStr)) == 1
      false_positives(nHashes, :) = false_positives(nHashes, :) + 1;
    end
    
    if rem(i, 10) == 0
      fprintf(".");
      
      if rem(i, 1000) == 0
        fprintf("\n");
       end 
    end
    
    
  end 
  
  waitbar(1, bar);
  delete(bar);
  
end

figure(1);
stem(false_positives/nTest);
hold on;

stem(false_positivesT);
title('Probabilidade simulada e te�rica dos falsos positivos');
xlabel('N� de fun��es de dispers�o');
ylabel('Probabilidade de falsos positivos');
axis([-0.5, 15.5, 0, 1]);

fprintf("Percentagem de falsos positivos: %4.2f%%\n", (false_positives/nTest)*100);


