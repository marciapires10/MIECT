%% Ex3

alfa_PT = ['a':'z', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', ...
    '�', '�', 'A':'Z', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', ...
    '�', '�', '0':'9']; 
    
files = {'pg21209.txt','pg26017.txt'};
pmf_PT = pmfLetrasPT(files, alfa_PT);
distLettersPT = cumsum(pmf_PT);
    
nBloom = inicialize(8000);
k = 3;
hashes = inicialize(k);

for i=1:k
  
  hashes(i) = ceil(rand()*1000);
  
endfor

nStr = 1000;
sizeStr = 40;

for i=1:nStr
  randStr = geraStrPT(sizeStr, alfa_PT, distLettersPT);
  nBloom = insert(nBloom, hashes, randStr);
endfor

nTest = 10000;
false_positives = 0;

for i=1:nTest
  
  randStr = geraStrPT(sizeStr, alfa_PT, distLettersPT);
  
  if verify(nBloom, hashes, randStr) == 1
    fprintf("%s Pertence \n");
    false_positives = false_positives + 1;
    
  else 
    fprintf("%s N�o pertence \n");
    
  end
  
endfor
  
fprintf("Percentagem de falsos positivos: %4.2f%%\n", (false_positives/nTeste)*100);