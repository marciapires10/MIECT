% Ex1, fun��o para inicializar a estrutura de dados

function funct_ini = inicialize(m)
  
  funct_ini = zeros(1, m, 'uint8');
  
endfunction
