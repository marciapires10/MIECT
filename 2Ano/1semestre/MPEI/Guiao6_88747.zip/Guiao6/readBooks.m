%% Ex5 e 6

function func_books = readBooks(src);
  
  book = fopen(src);
  book_scan = fscanf(src, '%c', inf);
  
  func_books = strsplit(book_scan);
  
endfunction
