%% Ex6

file = 'pg34742.txt'

func_books = readBooks(file);

nWords = length(func_books);
sizeBloom = nWords * 15;
k = round((sizeBloom/nWords)*log(2));
nBloom = inicialize(sizeBloom);

bar = waitbar(0, 'Criando o bloom filter para as palavras');

for i=1:nWords
  
  nBloom = insert(nBloom, k, func_books{i});
  
endfor

fprintf('N� de ocorr�ncias da palavra: ');

func_books = sort(unique(func_books));
nWords = length(func_books);
val = zeros(1, nWords);

for i=1:nWords
  word = func_books{i};
  val(i) = count(nBloom, k, word);
  fprintf('\%s :  %d\n', word, val(i));
  
endfor

[valMax, maxInd] = max(val);
fprintf('Palavra mais frequente: %s, aparecendo %d vezes\n', func_books{maxIn}, valMax); 