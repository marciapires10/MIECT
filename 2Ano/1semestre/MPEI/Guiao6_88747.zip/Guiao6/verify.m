% Ex1, fun��o para verificar se um elemento pertence ao conjunto

function  func_ver = verify(array, nHashes, obj);
  
  func_ver = 1;
  
  for i=1:length(nHashes)
    
    if array(nHashes(i)) != 1
      func_ver = 0;
      
    endif
  endfor
endfunction
