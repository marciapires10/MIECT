function func_str = geraStrPT(sizeStr, alfa_PT, distLettersPT)


    str = '';
    for i=1:sizeStr
        letterIndex = find(distLettersPT > rand());
        
        str(i) = alfa_PT(letterIndex(1));
    end

end