%% FUn��o de c�lculo de dist�ncia recorrendo a uma aproxima��o probabil�stica usando minHash

Set = dataEstr('u.data');
Nu = length(Set);

nHash = 10;
h = zeros(nHash, Nu);
minHash = zeros(nHash);

for i=1:nHash
  
  for n=1:Nu,
    keyHash = toString (Set(n) + num2str(i));
    h(i,n) = rem (string2hash(keyHash), n) + 1;
    
  endfor
  
   minHash(k) = min(h(i,:));
   
endfor

for i=1:nHash
  
  value = value + length(unique(h(i:i+1,:)));
endfor

SimilarJaccard = value / nHash;


