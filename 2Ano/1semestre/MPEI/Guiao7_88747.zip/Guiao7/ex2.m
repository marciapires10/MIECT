%% Testar o c�digo

Set = dataEstr('u.data');

J = calcJaccard(Set);

SimilarPairs = calcSP(Set, J, 0.4);