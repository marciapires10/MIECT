%% Processar as dist�ncias e devolver os itens similares

function SimilarPairs = calcSP(Set, J, thresold)
  
  Nu = length(Set);
  
  SimilarPairs = zeros(1,3);
  k = 1;
  
  for n1= 1:Nu,
    for n2= n1+1:Nu,
      if J(n1, n2) < 0.4
        SimilarPairs(k,:)= [Set(n1) Set(n2) J(n1,n2)]
        k= k+1;
      end
    end
  end
  
  NSimilarPairs = length(SimilarPairs);
  
  fprintf("Nr de pares de utilizadores com distancias inferiores ao limiar definido %1.1f: %d\n", threshold, NSimilarPairs)

  fprintf("\nInformacao sobre cada par\n")

  for i=1:NSimilarPairs
  
    fprintf("%d\t%d\t%f\n", SimilarPairs(i,1), SimilarPairs(i,2), SimilarPairs(i,3));
  
endfor

endfunction
