%% Calcular as dist�ncias de Jaccard

function J = calcJaccard (Set)
  
  Nu = length(Set);
  
  J = zeros(Nu);
  h = waitbar(0,'Calculating');
  
  for n1=1:Nu,
      waitbar(n1/Nu, h);
      
      for n2=n1+1:Nu,
        
        intersectLength = length(intersect(Set{n1}, Set{n2}));
        
        unionLenght = length(Set{n1}) + length(Set{n2}) - intersectLength;
        
        J(n1, n2) = 1 - intersectLength / unionLenght;
        
      end
      
  end

delete(h) 
  
endfunction
