%% Criar a estrutra de dados com o conjunto de filmes

function Set = dataEstr (file)
  
  udata = load(file);

  u = udata(1:end, 1:2);
  clear udata;

  users = unique(u(:,1));
  numberOfUsers = length(users);
  
  Set = cell(numberOfUsers, 1);
  
  for n = 1:numberOfUsers,
    
    ind = find(u(:,1) == users(n));
    
    Set{n} = [Set{n} u(ind,2)];
    
  endfor


endfunction
