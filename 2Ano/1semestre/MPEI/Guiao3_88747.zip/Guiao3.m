%%% Gui�o 3

%% Exerc�cio 1
% (a)

N = 10000;
nFaces = 6;

experiencias = ceil (nFaces * rand(1,N));
probFaces = histc(experiencias, 1:nFaces) / N;

figure(1);
subplot(1,2,1);

stem(1:6, probFaces);
xlabel('xi');
ylabel('P(X = xi)');
title('Funcao de massa de probabilidade de X');

% (b)

probAcum = cumsum(probFaces);

subplot(1,2,2);
stairs(0:nFaces+1, [0 probAcum 1]);

xlabel('xi');
ylabel('P(X <= xi)');
title('Funcao de distribuicao acumulada');

%% Exerc�cio 2

% (a)

% O espa�o de amostragem, S, desta experi�ncia consiste em 100 acontecimentos elementares equiprov�veis - retirar uma nota.
% A probabilidade de cada um destes acontecimentos elementares � de 1 / 100

% (b)

% O espa�o de amostragem da vari�vel aleat�ria X, S_X, consiste em 3 acontecimentos poss�veis:
%     1. retirar uma nota de 5�; 2. retirar uma nota de 50�; 3. retirar uma nota de 100�. Ou seja, S_X = {5, 50, 100}
% A probabilidade de cada acontecimento elementar � ent�o igual a n�mero de notas de valor xi / n�mero total de notas:
% P(5) = 90/100 = 0.9
% P(50) = 9/100 = 0.09
% P(100) = 1/100 = 0.01

% (c)

stem([5, 50, 100], [0.9, 0.09, 0.01]);
axis([0, 100, 0, 1]);

xlabel('xi');
ylabel('P(X = xi)');
title('Funcao massa de probabilidade de X');
grid on;

%% Exerc�cio 3

% (a)

N = 10000;
nLances = 4;

experiencias = rand(nLances, N);
nCoroas = sum(experiencias < 0.5);

probX = histc(nCoroas, 0:4) / N;

figure(2);
stem(probX);
xlabel('xi');
ylabel('P(X = xi)');
title('Funcao de probabilidade da vari�vel aleat�ria X');
grid on;

% (b)

valorEsperado = sum([0:nLances].*probX);
variancia = sum(([0:nLances]).^2.*probX) - valorEsperado^2;
desvioPadrao = sqrt(variancia);

fprintf('Valor esperado = %f\n', valorEsperado);
fprintf('Variancia = %f\n', variancia);
fprintf('Desvio-padr�o = %f\n', desvioPadrao);

% (c)

% X � uma vari�vel aleat�ria discreta Binomial. A sua respetiva fun��o �:
% P(X = k) = nchoosek(n, k)*(p)^k*(1-p)^(n-k)

% (d)

% P(X = xi) = nchoosek(4, xi))*((1/2)^4) com xi = {0,1,2,3,4}

% P(0) = 0.0625
% P(1) = 0.2500
% P(2) = 0.3750
% P(3) = 0.2500
% P(4) = 0.0625

% (e)

%% i.

probX = 1;

for i = 0:1
  probX = probX - nchoosek(4,i)*((1/2)^4);
endfor

fprintf('Probabilidade de sair 2 ou mais coroas: %f\n ', probX);

%% ii.

probY = 0;

for i = 0:1
  probY = probY + nchoosek(4,i)*((1/2)^4);
endfor

fprintf('Probabilidade de sair 1 ou menos coroas: %f\n ', probY);

% iii.

probZ = 0;

for i = 1:3
  probZ = probZ + nchoosek(4,i)*((1/2)^4);
endfor

fprintf('Probabilidade de sair 1, 2 ou 3 coroas: %f\n ', probZ);

%% Exerc�cio 4

% (a)

N = 10000;

experiencias = rand(5, N);
nPecas = sum (experiencias < 0.3);

figure(3);
probP = histc(nPecas, 0:5) / N;
stem(0:5, probP)

axis([-0.5 5.5 0 0.5])
xlabel('Nr de pecas defeituosas em 5 amostras');
ylabel('Probabilidade');
title('Distribuicao de probabilidades de X');

% (b)

probD = 0;

for k = 0:2 
  probD = probD + factorial(5)/(factorial(5-k)*factorial(k))*0.3^k*(1-0.3)^(5-k);
endfor

fprintf('TEORIA - Probabilidade de, no maximo, 2 das pecas de uma amostra serem defeituosas: %f\n', probD);

%%

sucesso = sum(experiencias < 0.3) <= 2;
probSucesso = sum(sucesso) / N;

fprintf('SIMULACAO - Probabilidade de, no maximo, 2 das pe�as de uma amostra serem defeituosas: %f\n', probSucesso);


%% Exerc�cio 5

% (a)

probFail = linspace(0,1);

probFail2 = nchoosek(2,2) * probFail.^2;

probFail4 = 0;

for i = 3:4
  probFail4 = probFail4 + nchoosek(4,i) * probFail.^i .* (1-probFail).^(4-i);
endfor

figure(4);
subplot(1,2,1);
plot(probFail, probFail2, probFail, probFail4);

xlabel('Probabilidade de falhar o motor');
ylabel('Probabilidade de o aviao se despenhar');
title('Probabilidade de falharem 2 ou 4 motores');


%% Exerc�cio 6

% Distribui��o binomial

N = 100;

experiencias = rand(8000, N);
chipDef = sum(experiencias < 1/1000);
sucesso = chipDef == 7;
probBinomial = sum(sucesso) / N;

fprintf('BINOMIAL - Probabilidade de numa amostra de 8000 chips, 7 serem defeituosos: %f\n', probBinomial);

%% Aproxima��o de Poisson

alfa = 8000*(1/1000);

probPoisson = (alfa^k/factorial(k)) * exp(-alfa);

fprintf('POISSON - Probabilidade de numa amostra de 8000 chips, 7 serem defeituosos: %f\n', probPoisson);

%% Exerc�cio 7

% (a)

% P(X = 0)?

probMensagem = exp(-15);

fprintf('Probabilidade de n�o receber mensagem durante 1 segundo: %f\n', probMensagem);

% (b)

% P(X > 10)?

i = 0:10;
probP = (15.^i).*exp(-15)./factorial(i);

probFinal = 1 - sum(probP);

fprintf('Probabilidade de receber pelo menos 10 mensagens durante 1 segundo: %f\n', probFinal);


%% Exerc�cio 8

values = [1:4];

fx = (values + 5)./30

%True se a fun��o f representar a probabilidade da fun��o massa de probabilidade de values

if( sum(fx) == 1 && max(fx) <= 1 && min(fx) >= 0)
  fprintf('True\n');
else
  fprintf('False\n');
end

%% Exerc�cio 9

% P(X >=1)? = 1 - P(X=0)

probErros = 1 - exp(-1);

fprintf('Probabilidade de que exista pelo menos um erro numa determianda pagina: %f\n', probErros);


%% Exerc�cio 10

% (a)
N = 10000;
x = rand(1,N)*10;

% Teoria

% P(0 <= X < 3)

probA1 = 3/10;

fprintf('Probabilidade de A por teoria: %f\n', probA1);

% Simula��o 

sucessoA = sum(x < 3);
probA2 = sucessoA / N;

fprintf('Probabilidade de A por simulacao: %f\n', probA2);

% (b)

% Teoria 

% P(7 < X <= 10) = 10-7/10

probB1 = 3/10;

fprintf('Probabilidade de B por teoria: %f\n', probB1);

% Simula��o 

sucessoB = sum(x > 7);
probB2 = sucessoB/N;

fprintf('Probabilidade de B por simulacao: %f\n', probB2);

% (c)

% Teoria

% P(1 < X < 6) = 6-1/10

probC1 = 5/10;

fprintf('Probabilidade de C por teoria: %f\n', probC1);

% Simula��o 

sucessoC = sum(x > 1 & x < 6);
probC2 = sucessoC / N;

fprintf('Probabilidade de C por simulacao: %f\n', probC2);

%% Exerc�cio 11

N = 10000;

x = (randn(1,N).*2) + 14;

% (a)

probA = (sum(x>=12) - sum(x>16)) / N;

fprintf('Probabilidade de um aluno do curso ter nota entre 12 e 16: %f\n', probA);

% (b)

probB = (sum(x>=10) - sum(x>18)) / N;

fprintf('Probabilidade de os alunos do curso terem classificacoes entre 10 e 18: %f\n', probB);

% (c)

probC = (sum(x>=10)) / N;

fprintf('Probabilidade de um aluno passar: %f\n', probC);


 


\