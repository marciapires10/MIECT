function func = geraStr (min, max)
  
  alfa = ['a':'z', 'A':'Z'];
  
  length = randi([min max]);
  
  str = '';
  
  for i=1:length
    func(i) = alfa(ceil(rand()*52));
  endfor
endfunction
