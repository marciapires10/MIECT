%%% Gui�o 5

%% Segunda vers�o

files = {'pg21209.txt','pg26017.txt'};

alfaPT = ['a':'z' 'A':'Z' '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', 'a':'z', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�','�', '�']

pmf_PT = pmfLetrasPT(files, alfaPT);

stem(pmf_PT)
distPT = cumsum(pmf_PT);

N = 1000;
factorC = 0.8;
m = round(N/factorC);


counter_djb2 = zeros(1,m);
counter_sdbm = zeros(1,m);

figure(1);

for i=1:N
  
  key2 = geraStr2(10, 5, alfaPT, distPT);
  
  val_djb2 = rem(string2hash(key2), m) +1;
  val_sdbm = rem(string2hash(key2, 'sdbm'), m) +1;
  
  counter_djb2(val_djb2) = counter_djb2(val_djb2) + 1;
  counter_sdbm(val_sdbm) = counter_sdbm(val_sdbm) + 1;
  
  if rem(i,25) == 0
    
    % djb2

    subplot(2,2,1)
    bar(counter_djb2, 'b')
    title('N� de strings mapeadas pela hash function (djb2)')

    subplot(2,2,2)
    hist(counter_djb2, 0:9, 'r')
    title('Histograma (djb2)')
    
    % sdbm

    subplot(2,2,3)
    bar(counter_sdbm, 'r')
    title('N� de strings mapeadas pela hash function (sdbm)')

    subplot(2,2,4)
    hist(counter_sdbm, 0:9, 'b')
    title('Histograma (sdbm)')
  
  endif
  
endfor


% djb2

figure(2);

subplot(1,2,1)

cnt_djb2 = histc(counter_djb2, 0:9);
prob_djb2 = cnt_djb2 / m;
stem(0:9, prob_djb2);

title('Fun��o de distribui��o de X (djb2)');
axis([-0.5, 9.5, 0, 1]);


fprintf('Resultados (djb2)');

e_x = sum([0:9].*prob_djb2);
fprintf('E[X] = %f\n', e_x);

e_x2 = sum(([0:9].^2).*prob_djb2);
fprintf('Var(X) = %f\n', e_x2 - e_x^2);

fprintf('\n') 

% sdbm

figure(3);

subplot(1,2,1)

cnt_sdbm = histc(counter_sdbm, 0:9);
prob_sdbm = cnt_sdbm / m;
stem(0:9, prob_sdbm);

title('Fun��o de distribui��o de X (sdbm)');
axis([-0.5, 9.5, 0, 1]);


fprintf('Resultados (sdbm)');

e_x = sum([0:9].*prob_sdbm);
fprintf('E[X] = %f\n', e_x);

e_x2 = sum(([0:9].^2).*prob_sdbm);
fprintf('Var(X) = %f\n', e_x2 - e_x^2);

fprintf('\n')

