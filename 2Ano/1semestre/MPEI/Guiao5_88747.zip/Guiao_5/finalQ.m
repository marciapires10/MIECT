%% Quest�es finais

% A fun��o de hash cumpriu o objetivo de espalhar as chaves/strings
% pelo array, obtendo assim uma distribui��o uniforme das chaves
% pelos �ndices do array