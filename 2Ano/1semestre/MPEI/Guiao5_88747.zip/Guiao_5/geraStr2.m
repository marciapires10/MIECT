function func = geraStr2 (mean, variance, alfa, distPT)
   
  length = mean + (sqrt(variance)*randn());
  
  str = '';
  
  for i=1:length
    letters = find(distPT > rand());
    func(i) = alfa(letters(1));
  endfor
endfunction
