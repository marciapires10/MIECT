%% Ex7, guiao8

% a)

matriz_trans = [0.8 0.1 0.05; ...
                0.2 0.6 0.20; ...
                0.0 0.3 0.75];
                
vetor_est = [100; 200; 30];

res3 = matriz_trans^3 * vetor_est;

%% ap�s 3 transi��es

fprint('Dinheiro da Ana: ', res3(1));
fprint('Dinheiro do Bernardo: ', res3(2));
fprint('Dinheiro da Catarina: ', res3(3));

% b)

res365 = matriz_trans^365 * vetor_est;

%% ap�s 1 ano

fprint('Dinheiro da Ana: ', res365(1));
fprint('Dinheiro do Bernardo: ', res365(2));
fprint('Dinheiro da Catarina: ', res365(3));

% c)

n = 1

res = matriz_trans * vetor_est;

while(1) 
  n = n+1;
  res = matriz_trans * res;
  
  if(res(3) > 130)
    break;
  end
  
end

[month, day] = func_date(n+1);

 fprintf('A Catarina ter� mais de 130 euros no dia: ', res(3), month, day);
 
   