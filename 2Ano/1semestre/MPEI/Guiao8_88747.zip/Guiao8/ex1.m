%% Ex1, guiao8

% probabilidade de ir � aula: 70%
% probabilidade de ir � aula, se faltou � anterior: 80%

matriz_tran = [ 0.7 0.8 ; 0.3 0.2 ]
vetor_est = [1;0]

% a)

prob = matriz_tran^2 * vetor_est

% b)

prob1 = matriz_tran^2 * [0;1]

% c)

prob2 = matriz_tran^30 * vetor_est

% d)

prob3 = [ 0.85 ; 0.15 ]
prob4 = zeros(1,30);

for i = 1:30
  res = matriz_tran^(i) * prob3;
  prob4(i) = res(2);
endfor

plot(prob4)
title('Probabilidade de faltar a cada uma das 30 aulas')
