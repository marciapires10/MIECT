%% Ex3, guiao8

matriz_trans = rand(20, 20, 1);

matriz_trans = matriz_trans./sum(matriz_trans);

%% 20 transi��es
prob = (matriz_trans^20);
fprintf('Probabilidade de traniscao entre o primeiro e ultimo estado com 20 transicoes: ', prob(1,20));

%% 40 transi��es
prob1 = (matriz_trans^40);
fprintf('Probabilidade de transicao entre o primeiro e ultimo estado com 40 transicoes: ', prob1(1,20));

%% 100 transi��es
prob2 = (matriz_trans^100);
fprintf('Probabilidade de transicao entre o primeiro e ultimo estado com 100 transicoes: ', prob2(1,20));

