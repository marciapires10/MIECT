%% Ex4, guiao8

% a)

p = 0.4;
q = 0.6;

matriz_trans = [p^2, 0, 0, q^2; ...
                (1-p)^2, 0, 0, q*(1-q); ...
                p*(1-p), 0, 0, q*(1-q); ...
                p*(1-p), 1, 1, (1-q)^2]
                
% b)

vetor_est = [1; 0; 0; 0]

prob = matriz_trans^10 * vetor_est

%% probabilidade sistema chegar ao estado B ap�s 10 transi��es adicionais caso inicialmente se encontre em A
fprintf('Probabilidade de chegar ao estado A: ', prob(1));
fprintf('Probabilidade de chegar ao estado B: ', prob(2));
fprintf('Probabilidade de chegar ao estado C: ', prob(3));
fprintf('Probabilidade de chegar ao estado D: ', prob(4));