%% Ex5, guiao8

% a)

matriz_trans = [ 0.7 0.2 0.1; 0.2 0.3 0.5; 0.3 0.3 0.4];

% b)

vetor_est = [1; 0; 0];

prob = matriz_trans^2 * vetor_est;
fprintf('Probabilidade de no dia 2 ser chuva: ', prob(3));

% c)

matriz = zeros(9, 20);

for i = 1:20
  matriz_exp = matriz_trans ^ i;
  matriz(:, i) = matriz_exp(:);
  
endfor

plot(matriz')

title('A evolu��o dos v�rios elementos da matriz em fun��o de n')

% d)

matriz1 = zeros(9, 20);

for i = 1:20
  matriz_exp = matriz_trans ^ i;
  if( i > 1 && abs(sum(matriz1(:, i-1)) - sum(values(:,i))) <= 10^-4)
    break;
   endif
   
  matriz1(:, i) = matriz_exp(:);
  
endfor

plot(matriz1')

title('A evolu��o dos v�rios elementos da matriz em fun��o de n')
