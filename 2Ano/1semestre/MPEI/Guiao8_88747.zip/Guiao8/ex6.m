%% Ex6, guiao8

% a)

matriz_trans = [0.8 0.0 0.3 0.0; ...
                0.2 0.9 0.2 0.0; ...
                0.0 0.1 0.4 0.0; ...
                0.0 0.0 0.1 1.0];
                
% b)

vetor_est = [1; 0; 0; 0];

prob = matriz_trans^1000 * vetor_est;

fprintf('Probabilidade de comecar na p�gina 1 e ao fim de 1000 passos estar na 2: ', prob(2));

%% Estava � espera deste valor porque o estado 4 � um estado absorvente

% c)

prob1 = zeros(4,4);
prob2 = zeros(4,4);
prob3 = zeros(4,4);

for i= 1:4
  matriz = [1;2;3;4] == i;
  
  res = matriz_trans^1 * matriz;
  prob1(:,i) = res(:);
  
  res = matriz_trans^2 * matriz;
  prob1(:,i) = res(:);
  
  res = matriz_trans^100 * matriz;
  prob1(:,i) = res(:);
  
endfor


% d)

Q = matriz_trans(1:3, 1:3);

% e)

F = inv(eye(3) - Q);

% f)

valor_esp = sum(matriz_fund);

fprintf('M�dia do n� de passos necess�rios para atingir p�gina 4 come�ando em 1: ', valor_esp(1));
fprintf('M�dia do n� de passos necess�rios para atingir p�gina 4 come�ando em 2: ', valor_esp(2));
fprintf('M�dia do n� de passos necess�rios para atingir p�gina 4 come�ando em 3: ', valor_esp(3));

% g)

fprintf('Tempo de absorcao para p�gina 1 ', valor_esp(1));
fprintf('Tempo de absorcao para p�gina 2 ', valor_esp(2));
fprintf('Tempo de absorcao para p�gina 3 ', valor_esp(3));

% h)

matriz_trans1 = [0.8 0.1 0.5 0.0; ...
                 0.2 0.8 0.25 0.0; ...
                 0.0 0.1 0.2 0.0; ...
                 0.0 0.0 0.05 1.0];
                 
Q1 = matriz_trans1(1:3,1:3);
F1 = inv(eye(3) - Q1);
valor_esp = sum(F1);

fprintf('Tempo de absorcao para p�gina 1 ', valor_esp(1));
fprintf('Tempo de absorcao para p�gina 2 ', valor_esp(2));
fprintf('Tempo de absorcao para p�gina 3 ', valor_esp(3));
