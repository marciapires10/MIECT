function [month, day] = func_date(days)
  
  months = {'janeiro', 'fevereiro', 'marco', 'abril', 'maio', 'junho', 'julho',
             'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'};
             
  days_month = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];
  
  days_year = cumsum(days_month);
  
  n = find(days < days_year, 1);
  
  month = months{n};
  
  if(n > 1)
    day = days - days_year(n-1);
  else
    day = days;
  end 
  
endfunction
