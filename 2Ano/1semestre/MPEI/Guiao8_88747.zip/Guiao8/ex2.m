%% Ex2, guiao8

% a)

matriz_trans = [ 1/3 1/4 0; 1/3 11/20 1/2; 1/3 1/5 1/2]

% matriz estoc�stica? todas as colunas t�m soma de entradas igual a 1

if (sum(matriz_trans(:,1)) == sum(matriz_trans(:,2)) && sum(matriz_trans(:, 2)) == sum(matriz_trans(:, 3)) && sum(matriz_trans(:, 3)) == 1) fprintf('� matriz estoc�stica');
else fprintf('N�o � matriz estoc�stica');
end

% b)
%% 90 = a + b +c 
%% b + c = x
%% a = 2 * x
%% 90 = 2x + x
%% x = 30
%% a = 60
%% b = c = 15

vetor_est = [ 60/90; 15/90; 15/90 ]

% c)

prob = matriz_trans^30 * vetor_est

fprintf('N�mero de elementos no grupo A: ', prob(1) * 90);
fprintf('N�mero de elementos no grupo B:', prob(2) * 90);
fprintf('N�mero de elementos no grupo C:', prob(3) * 90);

% d)

vetor_est1 = [ 30/90; 30/90; 30/90 ]

prob1 = matriz_trans^30 * vetor_est1

fprintf('N�mero de elementos no grupo A: ', prob1(1) * 90);
fprintf('N�mero de elementos no grupo B:', prob1(2) * 90);
fprintf('N�mero de elementos no grupo C:', prob1(3) * 90);